const Koa = require('koa')
const router = require('koa-router')
const session = require('koa-session')
const bodyParser = require('koa-bodyparser')
const isString = require('underscore').isString
const views = require('koa-views')
const path = require('path')
const static = require('koa-static')
const http = require('http')
const fs = require('fs')
const md5 = require('md5');
const qs = require('qs');

const app = new Koa()
const home  = new router()
const CONFIG = {
    key: 'koa:sess',
    maxAge: 1800000,
    overwrite: true,
    httpOnly: true,
    signed: true, 
    rolling: false, 
    renew: false, 
  };


function checkUser(username){
    while(username.match(/admin/i)) {
      username = username.replace(/admin/i, '');
    }

    if(isString(username) && username){
        return username;
    }else{
        return undefined;
    }
}

function checkUrl(url){
    if(url.indexOf("http://"+server_ip+":3000/query") === 0 && url.indexOf('save') === -1){
        return url;     
    }else{
        return 'errorurl';
    }
}


function WriteResults(sandbox,data){
    let filePath = sandbox +'/results.txt'

    return new Promise(resolve =>{
            fs.appendFile(filePath,data,'utf8',function(error){
                if(error){
                    console.log(error);
                    return false;
                }
                console.log('写入成功');
                resolve(filePath);
            });
    });
}


function DeleteResults(sandbox){
    let filePath = sandbox+'/results.txt'

    fs.unlink(filePath),function(error){
        if(error){
            console.log(err);
            return false;
        }
        console.log('删除文件成功');
    }

  
}


home.get('/query',async(ctx)=>{
    if(ctx.query.param){
        ctx.response.body = String(ctx.query.param).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    }else{
        ctx.status = 403;
        ctx.response.body = 'missing parameter:param';
    }
})


home.get('/request',async(ctx)=>{
    if(ctx.session.username === 'ADMIN' && ctx.query.url){
        url = decodeURI(checkUrl(ctx.query.url))
        if(url === 'errorurl'){
            ctx.response.body = 'error url';
        }else{
            console.log("请求的url:"+typeof(url)+":"+url);
            return new Promise( resolve => {
                const req = http.request(url, res => {
                    res.setEncoding('utf-8');
                    let data = '';
                    let error;
                        
                    if (res.statusCode !== 200){
                        error = new Error('请求失败\n' +
                        `状态码: ${res.statusCode}`)
                    };

                    if (error) {
                        console.error(error.message);
                        res.resume();
                        return;
                    }
                    res.on('data', chunk => {
                        data += chunk.toString();
                    });
                    res.on('end', async() => {
                        let out = await WriteResults(ctx.session.sandbox,data);
                        ctx.body = 'Requst results in :'+out.replace('tmp','');
                        resolve();
                    })
                })
                
                req.on('error', function(err){
                    console.log(err);
                  });
                  
                req.end();
            });
        }
    }else{
        ctx.status = 403;
        ctx.response.body = '403: You have not the permission'
    }
})

home.get('/save',async(ctx)=>{
    let ip = ctx.request.ip;

    if (ip.substr(0, 7) == "::ffff:") {
        ip = ip.substr(7);
    }
    if (ip !== '127.0.0.1' && ip !== server_ip) {
        ctx.status = 403;
        ctx.response.body = '403: You are not the local user';
    }else {
        let reqbody = {switch:false}
        reqbody = qs.parse(ctx.querystring,{allowPrototypes: false});

        if(reqbody.switch === true && reqbody.sandbox && reqbody.opath &&fs.existsSync(reqbody.spath)){
            if(fs.existsSync(reqbody.sandbox)){
                paths.opath = fs.readdirSync(reqbody.sandbox)[0];
            }else if(fs.existsSync(reqbody.opath)){
                let buffer;
                tmp[reqbody.sandbox]['opath'] = reqbody.opath;
                if(/[flag]/.test(tmp[reqbody.sandbox]['opath'])){
                    buffer = tmp[reqbody.sandbox]['opath'].replace(/f|l|a|g/g,'');
                }else{
                    buffer = reqbody.opath;
                }
            }
            let opath = paths.opath? paths.opath : buffer;
            let text = fs.readFileSync(opath, 'utf8');
            await WriteResults(reqbody.spath,text);

        }else{
            return false;
        }
    }
})

home.get('/delete',async(ctx)=>{
    if(ctx.session.username === 'ADMIN' && fs.existsSync(ctx.session.sandbox+'/results.txt')){
        DeleteResults(ctx.session.sandbox);
        ctx.response.body = 'Delete the results Successfully!'
    }else{
        ctx.response.body = 'Nothing to delete!';
    }
})

home.get('/login',async(ctx)=>{
    if(ctx.query.userName){
        let username = checkUser(ctx.query.userName);
        if (username !== undefined){
            ctx.session.username = username.toUpperCase();       
        }
    }
    ctx.redirect('/');
})

home.get('/',async(ctx)=>{
    let isAdmin = undefined;
    if(!ctx.session.username){
        await ctx.render('user',{
            list:undefined,
            isAdmin:isAdmin
        });
    }else{
        info.username = ctx.session.username;
        info.Privilege = "Staff";
        if(ctx.session.username === 'ADMIN'){
            info.Privilege = "Monitor";
            isAdmin = true;

            if(!ctx.session.sandbox){
                ctx.session.sandbox = 'tmp/'+md5(ctx.request.ip);
            }
            
            if (!fs.existsSync(ctx.session.sandbox)){
                fs.mkdirSync(ctx.session.sandbox);
            }
        }
        await ctx.render('user',{
            list:info,
            isAdmin:isAdmin
        });
    }
})

app.keys = ['hpdoger'];
var info = new Object();
var tmp = [];
var paths = [];

//depend on remote server,not real
var server_ip = '127.0.0.1'

app.use(views(path.join(__dirname, './views'), {
    extension: 'ejs'
}))

app.use(static(
    path.join( __dirname,  './static')
  ))
app.use(static(
    path.join( __dirname,  './tmp')
))

app.use(bodyParser())
app.use(session(CONFIG, app));
app.use(home.routes()).use(home.allowedMethods());


app.listen(3000)
console.log('[demo] start-quick is starting at port 3000')